function Termekek({ nev, leiras, ar }) {
  return (
    <div className="termek-kartya">
      <h3>{nev}</h3>
      <p>{leiras}</p>
      {ar && <p>Ár: {ar} Ft</p>}
    </div>
  );
}

function Termek({ adat }) {
  
  const { nev, ár, raktár, leírás } = adat;

 
  const isElerheto = raktarmenyiseg > 0;
  const statuszStilus = {
    color: isElerheto ? 'green' : 'red',
    fontWeight: 'bold'
  };

  return (
    <div className="termek-kartya" style={{ border: '1px solid #ccc', padding: '15px', margin: '10px 0' }}>
      <h3>{nev}</h3>
      <p><strong>Leírás:</strong> {leírás}</p>
      <p><strong>Ár:</strong> {ár} Ft</p>
      <p><strong>Raktáron:</strong> {raktár} db</p>
      
      {}
      <p style={statuszStilus}>
        {isElerheto ? 'Rendelhető' : 'Elfogyott'}
      </p>
    </div>
  );
}





const termekek = [
    {
        id: 1,
        nev: 'bögre',
        ár: 500,
        raktár: 100,
        leírás: 'Fehér alapú 2.5dl bögre, egyedi képpel',
    },
    {
        id: 2,
        név: póló,
        ár: 3000,
        raktár: 300,
        leírás: 'Többféle alapszínű és méretű minőségi póló, elején vagy hátulján kérhető legfeljebb 5 szavas felirattal',

    },
    {
        id: 3,
        név: sapka,
        ár: 2000,
        raktár: 0,
        leírás: 'Többféle alapszínű baseball sapka, elejére kérhető emblémával',
    },
    {
        id: 4,
        név: esernyő,
        ár: 2500,
        raktár: 50,
        leírás: 'Kis átmérőjű fekete vagy fehér kicsire összecsukható esernyő egy emblémával',
    },
]